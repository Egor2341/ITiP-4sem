package org.example;

public class Main {
    public static void main(String[] args) {
        Administrator ivan = new Administrator("Ivan", "Ivanov",
                20, 100000.00, "finance");
        Manager maria = new Manager("Maria", "Semenova",
                25, 120000.60, 10);
        Programmer maxim = new Programmer("Maxim", "Maximov",
                30, 150000.30, "Java");
        Programmer victor = new Programmer("Victor", "Petrov",
                21, 99000.99, "Java");
        ivan.activity();
        System.out.println(maria.getAge());
        maxim.commitChanges("new feature");
        System.out.println(victor.getProgrammingLanguage());
    }
}
