package org.example;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
abstract public class Employee {
    protected String name;
    protected String surname;
    protected int age;
    protected double salary;

    abstract public void activity();
}
