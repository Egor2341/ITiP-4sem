package org.example;
import lombok.*;

@Getter
@Setter
public class Administrator extends Employee{
    private String department;

    public Administrator(String name, String surname, int age, double salary, String department) {
        super(name, surname, age, salary);
        this.department = department;
    }

    @Override
    public void activity() {
        System.out.println(name + " " + surname + " administers");
    }

    public void conclusionContract(String contract) {
        System.out.println("Contract " + contract + " is concluded");
    }
}
