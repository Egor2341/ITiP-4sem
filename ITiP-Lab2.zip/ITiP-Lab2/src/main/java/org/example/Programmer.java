package org.example;
import lombok.*;

@Getter
@Setter
public class Programmer extends Employee{
    private String programmingLanguage;

    public Programmer(String name, String surname, int age, double salary, String programmingLanguage) {
        super(name, surname, age, salary);
        this.programmingLanguage = programmingLanguage;
    }

    @Override
    public void activity() {
        System.out.println(name + " " + surname + " programming");
    }

    public void commitChanges(String commit) {
        System.out.println("Commit " + commit + " is made");
    }
}
