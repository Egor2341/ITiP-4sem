package org.example;
import lombok.*;

@Getter
@Setter
public class Manager extends Employee {
    private int countSubordinates;

    public Manager(String name, String surname, int age, double salary, int countSubordinates) {
        super(name, surname, age, salary);
        this.countSubordinates = countSubordinates;
    }

    @Override
    public void activity() {
        System.out.println(name + " " + surname + " manages");
    }

    public void meeting(String theme) {
        System.out.println("Meeting " + theme + " started");
    }
}
